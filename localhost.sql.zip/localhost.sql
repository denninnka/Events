-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 15, 2017 at 07:39 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `events`
--
CREATE DATABASE IF NOT EXISTS `events` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `events`;

-- --------------------------------------------------------

--
-- Table structure for table `Notes`
--

CREATE TABLE `Notes` (
  `note_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `note_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Notes`
--

INSERT INTO `Notes` (`note_id`, `title`, `description`, `created_at`, `updated_at`, `user_id`, `note_date`) VALUES
(1, 'Бележка 1', 'Дълго описание за бележка 1', '2017-08-15 00:36:27', '2017-08-15 00:36:27', 1, '2017-08-01'),
(2, 'Бележка 2', 'Дълго описание за бележка 1', '2017-08-15 00:36:43', '2017-08-15 00:36:43', 1, '2017-08-01'),
(3, 'Бележка 3', 'Дълго описание за бележка 3', '2017-08-15 00:36:55', '2017-08-15 00:36:55', 1, '2017-08-01'),
(4, ' Забележка 1 ', ' Дълго описание за забележка 1 ', '2017-08-15 00:37:35', '2017-08-15 01:08:07', 1, '2017-08-03'),
(5, ' Забележка 2 ', ' Дълго описание за забележка 2 ', '2017-08-15 00:37:50', '2017-08-15 01:10:29', 1, '2017-08-31'),
(7, 'Събитието', 'Събитието на века', '2017-08-15 00:38:31', '2017-08-15 00:38:31', 1, '2017-08-22'),
(8, 'Лекар', 'Света Ана от 10:00ч', '2017-08-15 00:38:58', '2017-08-15 00:38:58', 1, '2017-08-22'),
(9, 'asdasd', 'asdasd', '2017-08-15 02:00:59', '2017-08-15 02:00:59', 2, '2017-08-09');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_id`, `username`, `password`) VALUES
(1, 'denninnka', '$2y$10$y5kv0qoXRLrFS0YUeenACeDjnt9rsCqTJq2xEDL6qoSMghPoPREhm'),
(2, 'denito', '$2y$10$znDiHyQm6YCuwdHZiQiXq.CDFxRvziLDLZ6ZgQXfF.wihiNqwx.ka'),
(3, 'desito', '$2y$10$JDqyMZpyQM/YbhJ4ogFosOQ5PQ/UcnxRL5I5LlaXbOQDTK3h5tuV2'),
(4, 'Ivanov', '$2y$10$HEZhp48anncEule.JZuol.efPjo2XqvIWtzXdcizublacASPBIEiy'),
(5, 'ivanova', '$2y$10$U5.G9gs/Nw2YoeFMYWAVE.S8IDhtK8T1xJAD.LwS45Nde8dwfAwNi'),
(6, 'Ilian', '$2y$10$fUVWPoGArq3Mb.Deu/HCIe2Adtf9YuMLKSZXWuNuskZ75K/ZNkiUG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Notes`
--
ALTER TABLE `Notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Notes`
--
ALTER TABLE `Notes`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
